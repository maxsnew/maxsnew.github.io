        section .text
        global entry
entry:
        ;; applyToFive(incr)
        ;; The following is the correct way to implement the "naive"
        ;; mov rdi, incr
        lea rdi, [rel incr]
        jmp applyToFive
        
;;; def incr(x): x + 1
incr:
        add rdi, 2
        mov rax, rdi
        ret
;;; def applyToFive(f): f(5)
applyToFive:
        mov rax, rdi
        mov rdi, 10
        jmp rax
