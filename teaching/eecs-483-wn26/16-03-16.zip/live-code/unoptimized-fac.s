section .text
        global entry
        extern snake_error
        extern snake_new_array
arithmetic_overflow_err:
        mov rdi, 0
        sub rsp, 8
        call snake_error
expected_num_err:
        mov rdi, 1
        sub rsp, 8
        call snake_error
expected_bool_err:
        mov rdi, 2
        sub rsp, 8
        call snake_error
expected_array_err:
        mov rdi, 3
        sub rsp, 8
        call snake_error
negative_length_err:
        mov rdi, 4
        sub rsp, 8
        call snake_error
index_out_of_bounds_err:
        mov rdi, 5
        sub rsp, 8
        call snake_error
entry:
        mov QWORD [rsp + -8], rdi
        jmp entry#0
entry#0:
        mov rax, QWORD [rsp + -8]
        mov QWORD [rsp + -16], rax
        mov rax, 0
        mov QWORD [rsp + -24], rax
        mov rsi, QWORD [rsp + -16]
        mov rax, rsi
        and rax, 3
        cmp rax, 3
        jne expected_array_err
        mov rsi, QWORD [rsp + -24]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rax, QWORD [rsp + -16]
        mov r10, 3
        xor rax, r10
        mov QWORD [rsp + -32], rax
        mov rax, QWORD [rsp + -32]
        mov r10, 0
        imul r10, 8
        add r10, rax
        mov rax, QWORD [r10 + 0]
        mov QWORD [rsp + -40], rax
        mov rax, QWORD [rsp + -24]
        sar rax, 1
        mov QWORD [rsp + -48], rax
        mov r10, QWORD [rsp + -40]
        mov rax, QWORD [rsp + -48]
        mov rsi, rax
        sal rsi, 1
        cmp rax, 0
        jl index_out_of_bounds_err
        cmp r10, rax
        jle index_out_of_bounds_err
        mov rax, QWORD [rsp + -48]
        mov r10, 1
        add rax, r10
        jo arithmetic_overflow_err
        mov QWORD [rsp + -56], rax
        mov rax, QWORD [rsp + -32]
        mov r10, QWORD [rsp + -56]
        imul r10, 8
        add r10, rax
        mov rax, QWORD [r10 + 0]
        mov QWORD [rsp + -64], rax
        mov rax, QWORD [rsp + -64]
        mov QWORD [rsp + -72], rax
        mov rax, 2
        mov QWORD [rsp + -80], rax
        mov rax, QWORD [rsp + -72]
        mov QWORD [rsp + -72], rax
        mov rax, QWORD [rsp + -80]
        mov QWORD [rsp + -80], rax
        jmp fact#1
fact#1:
        mov rax, QWORD [rsp + -72]
        mov QWORD [rsp + -88], rax
        mov rax, 0
        mov QWORD [rsp + -96], rax
        mov rsi, QWORD [rsp + -88]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rsi, QWORD [rsp + -96]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rax, QWORD [rsp + -88]
        mov r10, QWORD [rsp + -96]
        cmp rax, r10
        mov rax, 0
        setle al
        mov QWORD [rsp + -104], rax
        mov rax, QWORD [rsp + -104]
        shl rax, 2
        mov QWORD [rsp + -112], rax
        mov rax, QWORD [rsp + -112]
        mov r10, 1
        or rax, r10
        mov QWORD [rsp + -120], rax
        mov rsi, QWORD [rsp + -120]
        mov rax, rsi
        and rax, 3
        cmp rax, 1
        jne expected_bool_err
        mov rax, QWORD [rsp + -120]
        sar rax, 2
        mov QWORD [rsp + -128], rax
        mov rax, QWORD [rsp + -128]
        cmp rax, 0
        jne thn#2
        jmp els#3
thn#2:
        mov rax, QWORD [rsp + -80]
        ret
els#3:
        mov rax, QWORD [rsp + -72]
        mov QWORD [rsp + -88], rax
        mov rax, 2
        mov QWORD [rsp + -96], rax
        mov rsi, QWORD [rsp + -88]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rsi, QWORD [rsp + -96]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rax, QWORD [rsp + -88]
        mov r10, QWORD [rsp + -96]
        sub rax, r10
        jo arithmetic_overflow_err
        mov QWORD [rsp + -104], rax
        mov rax, QWORD [rsp + -80]
        mov QWORD [rsp + -112], rax
        mov rax, QWORD [rsp + -72]
        mov QWORD [rsp + -120], rax
        mov rsi, QWORD [rsp + -112]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rsi, QWORD [rsp + -120]
        mov rax, rsi
        and rax, 1
        cmp rax, 0
        jne expected_num_err
        mov rax, QWORD [rsp + -112]
        sar rax, 1
        mov QWORD [rsp + -128], rax
        mov rax, QWORD [rsp + -128]
        mov r10, QWORD [rsp + -120]
        imul rax, r10
        jo arithmetic_overflow_err
        mov QWORD [rsp + -136], rax
        mov rax, QWORD [rsp + -104]
        mov QWORD [rsp + -72], rax
        mov rax, QWORD [rsp + -136]
        mov QWORD [rsp + -80], rax
        jmp fact#1

