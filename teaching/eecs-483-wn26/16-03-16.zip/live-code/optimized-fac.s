section .text
        global entry
        extern snake_error
        extern snake_new_array
arithmetic_overflow_err:
        mov rdi, 0
        mov rsi, rax
        sub rsp, 8
        call snake_error
expected_num_err:
        mov rdi, 1
        mov rsi, rax
        sub rsp, 8
        call snake_error
expected_bool_err:
        mov rdi, 2
        mov rsi, rax
        sub rsp, 8
        call snake_error
expected_array_err:
        mov rdi, 3
        mov rsi, rax
        sub rsp, 8
        call snake_error
negative_length_err:
        mov rdi, 4
        sal rax, 1
        mov rsi, rax
        sub rsp, 8
        call snake_error
index_out_of_bounds_err:
        mov rdi, 5
        sal rax, 1
        mov rsi, rax
        sub rsp, 8
        call snake_error
entry:
        jmp entry#0
entry#0:
        mov rsi, 0
        mov rax, rdi
        and rax, 3
        cmp rax, 3
        mov rax, rdi
        jne expected_array_err
        mov rax, 3
        xor rdi, rax
        mov rax, 0
        imul rax, 8
        add rax, rdi
        mov rax, QWORD [rax + 0]
        mov rdx, rax
        sar rsi, 1
        mov rax, rsi
        cmp rax, 0
        jl index_out_of_bounds_err
        cmp rdx, rax
        jle index_out_of_bounds_err
        mov rax, 1
        add rsi, rax
        jo arithmetic_overflow_err
        mov rax, rsi
        imul rax, 8
        add rax, rdi
        mov rax, QWORD [rax + 0]
        mov rdi, rax
        mov rsi, 0
        mov rax, rdi
        and rax, 1
        cmp rax, 0
        mov rax, rdi
        jne expected_num_err
        mov rax, rsi
        add rdi, rax
        jo arithmetic_overflow_err
        mov rsi, 2
        jmp fact#1
fact#1:
        mov rdx, 0
        mov rax, rdx
        mov rdx, rdi
        cmp rdx, rax
        mov rdx, 0
        setle dl
        sal rdx, 2
        mov rax, 1
        or rdx, rax
        sar rdx, 2
        mov rax, rdx
        cmp rax, 0
        jne thn#2
        jmp els#3
thn#2:
        mov rax, rsi
        ret
els#3:
        mov rdx, 2
        mov rax, rdx
        mov rdx, rdi
        sub rdx, rax
        jo arithmetic_overflow_err
        sar rsi, 1
        mov rax, rdi
        mov rdi, rsi
        imul rdi, rax
        jo arithmetic_overflow_err
        mov rsi, rdi
        mov rdi, rdx
        jmp fact#1

