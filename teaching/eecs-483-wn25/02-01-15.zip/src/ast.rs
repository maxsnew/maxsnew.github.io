type Var = String;

#[derive(Clone, Debug)]
pub struct Program {
    pub parameter: Var,
    pub body: Expression,
}

#[derive(Clone, Debug)]
pub enum Expression {
    Variable(Var),
    Number(i64),
    Add1(Box<Expression>),
    Sub1(Box<Expression>),
    Let(Var, Box<Expression>, Box<Expression>),
}
