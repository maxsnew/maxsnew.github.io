let s = X86.string_of_prog (X86.p5)

;; print_endline s
