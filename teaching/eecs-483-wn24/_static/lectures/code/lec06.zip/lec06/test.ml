let varX1 = ref (1L)
let varX2 = ref (2L)
let varX3 = ref (3L)
let varX4 = ref (4L)
let varX5 = ref (5L)
let varX6 = ref (6L)
let varX7 = ref (7L)
let varX8 = ref (8L)
;;
let program () =
let rec entry () =
let _ = store (6L) varX1 in
let _ = store (1L) varX2 in
  br entry8

and entry8 () =
let tmp1 = load varX1 in
let guard7 = icmp eq tmp1 (0L) in
  cbr guard7 exit10 body9

and body9 () =
let tmp4 = load varX2 in
let tmp5 = load varX1 in
let tmp6 = mul tmp4 tmp5 in
let _ = store tmp6 varX2 in
let tmp2 = load varX1 in
let tmp3 = add tmp2 (-1L) in
let _ = store tmp3 varX1 in
  br entry8

and exit10 () =
  ret ()
in entry ()
