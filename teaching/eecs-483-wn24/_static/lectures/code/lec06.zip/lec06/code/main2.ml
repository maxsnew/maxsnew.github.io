open Ir2

(* NOTE: try other examples as well *)
let _ = 
  let p  = SRC.example_cmd in
  let ir = Compile.compile p in
  let s  = IR.pp_program ir in
  print_endline s
