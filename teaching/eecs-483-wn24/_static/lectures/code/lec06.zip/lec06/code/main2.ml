open Ir2

let _ = 
  let p  = SRC.example_cmd in
  let ir = Compile.compile p in
  let s  = IR.pp_program ir in
  print_endline s
