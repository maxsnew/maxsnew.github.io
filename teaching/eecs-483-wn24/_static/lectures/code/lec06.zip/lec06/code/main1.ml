open Ir1

let _ = 
  let p  = SRC.example in
  let ir = Compile.compile p in
  let s  = IR.pp_program ir in
  print_endline s
