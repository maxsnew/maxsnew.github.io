let s = X86.string_of_prog (X86.p3 6)

;; print_string s
