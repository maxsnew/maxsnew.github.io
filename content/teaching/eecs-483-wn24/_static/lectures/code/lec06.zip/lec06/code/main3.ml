open Ir3

(* Also try SRC.factorial *)
let _ = 
  let prog = SRC.example_branch in
  let ir = Compile.compile prog in
  let s  = IR.pp_program ir in
  print_endline s
