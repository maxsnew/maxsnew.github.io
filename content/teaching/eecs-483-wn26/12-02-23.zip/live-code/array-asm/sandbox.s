        section .text
        global entry
        extern snake_error
        extern new_array
        extern print_snake_value

;;; def main(x):
;;;   let _ = print(newArray(x)) in
;;;   newArray(2)
entry:
        ;; input is x in rdi
        ;; allocate an array of length x
        sar rdi, 1
        sub rsp, 8
        call new_array
        add rsp, 8
        ;; save the array value to the stack
        mov [rsp - 8], rax
        mov rdi, rax
        sub rsp, 8
        call print_snake_value
        add rsp, 8
        mov rdi, 2
        sub rsp, 8
        call new_array
        add rsp, 8
        ret
        
