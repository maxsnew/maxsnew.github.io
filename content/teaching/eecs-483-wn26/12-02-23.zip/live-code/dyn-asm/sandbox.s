        section .text
        global entry
        extern snake_error
entry:
        ;; jmp integer_const
        ;; jmp true_const
        ;; jmp false_const
        ;; jmp addition
        ;; jmp subtraction
        ;; jmp multiplication
        ;; jmp leq
        ;; jmp equality
        ;; jmp logical_and
        ;; jmp logical_not
        jmp checked_addition

;;; Constants
integer_const:
        ;;  return a constant integer 7
        mov rax, 14
        ret
true_const:
        ;; return true
        mov rax, 0b101
        ret
false_const:
        ;; return false
        mov rax, 0b001
        ret

;;; Arithmetic operations
addition:
        ;; rdi + rsi
        mov rax, rdi
        add rax, rsi
        ret
subtraction:
        ;; rdi - rsi
multiplication:
        ;; rdi * rsi
        mov rax, rdi
        sar rax, 1
        imul rax, rsi
        ret
        
;;; Comparison operations
leq:
        ;; rdi <= rsi
        cmp rdi, rsi
        mov rax, 0
        setle al
        sal rax, 2
        add rax, 1
        ret
equality:
        ;; rdi == rsi
        cmp rdi, rsi
        mov rax, 0
        sete al
        sal rax, 2
        add rax, 1
        ret
        

logical_and:
        ;; rdi && rsi
        mov rax, rdi
        and rax, rdi
        ret
logical_not:    
        ;; ! rdi
        mov rax, rdi
        xor rax, 0b100
        ret

checked_addition:
        ;; rdi + rsi, but raise an error if rdi, rsi are not integers
        test rdi, 0b1
        jnz arithmetic_error
        test rsi, 0b1
        jnz arithmetic_error
        jmp addition

arithmetic_error:
        mov rdi, 0
        sub rsp, 8
        call snake_error
