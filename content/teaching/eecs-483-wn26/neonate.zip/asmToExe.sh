#!/usr/bin/env bash

os_type=$(uname -s)

if [ $# -ne 1 ]; then
    echo "Usage: $0 <input_file>"
    exit 1
fi

if [ "$os_type" = "Darwin" ]; then
    format="macho64"
    extra_args="--target=x86_64-apple-darwin"
elif [ "$os_type" = "Linux" ]; then
    format="elf64"
else
    echo "unknown platform"
    exit 1
fi

# Pipeline after our compiler runs

# x86_64 (output of our compiler)
# --[ nasm ]--> object file
# --[ ar ]--> archive file
# --[ ld ]--> Executable     links with our "runtime system" in stub.rs

nasm -f $format -o compiled_code.o $1 \
 && ar rus libcompiled_code.a compiled_code.o \
 && rustc stub.rs -L . $extra_args -o main.exe
