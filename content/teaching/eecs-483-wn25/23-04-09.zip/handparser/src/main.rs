use std::iter::Peekable;

#[derive(Debug, Eq, PartialEq)]
enum Token {
    Num(i64),
    Plus,
    LParen,
    RParen,
}

#[derive(Debug)]
enum Ast {
    Num(i64),
    Plus(Box<Ast>, Box<Ast>),
}

/* Our LL(1) grammar
 * T  ⟼ S$
 *
 * S  ⟼ ES'
 *
 * S’ ⟼ e
 * S’ ⟼ + S
 *
 * E  ⟼ $
 * */

struct ParserState<'t, I>
where
    I: Iterator<Item = &'t Token>,
{
    toks: Peekable<I>,
}

impl<'t, I> ParserState<'t, I>
where
    I: Iterator<Item = &'t Token>,
{
    fn parse_eof(&mut self) -> Result<(), String> {
        match self.toks.next() {
            None => Ok(()),
            Some(c) => Err(format!("expected EOF, found {:?}", c)),
        }
    }

    fn parse_num(&mut self) -> Result<i64, String> {
        match self.toks.next() {
            Some(Token::Num(n)) => Ok(*n),
            _ => Err(String::from("expected num"))
        }
    }

    fn parse_tok(&mut self, c: Token) -> Result<(), String> {
        match self.toks.next() {
            None => Err(format!("expected {:?}, got EOF", c)),
            Some(d) => {
                if c == *d {
                    Ok(())
                } else {
                    Err(format!("expected {:?}, found {:?}", c, d))
                }
            }
        }
    }
    /* T
     * on number | (
     * transition to S $
     * */
    fn parse_t(&mut self) -> Result<Ast, String> {
        println!("State: T \t\tLookahead: {:?}", self.toks.peek());
        match self.toks.peek() {
            Some(Token::Num(_)) | Some(Token::LParen) => {
                let ans = self.parse_s()?;
                let _ = self.parse_eof()?;
                Ok(ans)
            }
            _ => Err(String::from("expected '(' or number")),
        }
    }

    /* S
     * on number | (
     * transition to E S'
     */
    fn parse_s(&mut self) -> Result<Ast, String> {
        println!("State: S \t\tLookahead: {:?}", self.toks.peek());
        match self.toks.peek() {
            Some(Token::Num(_)) | Some(Token::LParen) => {
                let prefix = self.parse_e()?;
                self.parse_s_prime(prefix)
            }
            _ => Err(String::from("expected '(' or number")),
        }
    }

    /* S'
     * on + transition to + S
     * on ) or EOF transition to ε
     * */
    fn parse_s_prime(&mut self, prefix: Ast) -> Result<Ast, String> {
        println!("State: S'\t\tLookahead: {:?}", self.toks.peek());
        match self.toks.peek() {
            Some(Token::Plus) => {
                self.parse_tok(Token::Plus)?;
                let suffix = self.parse_s()?;
                Ok(Ast::Plus(Box::new(prefix), Box::new(suffix)))
            }
            Some(Token::RParen) | None => Ok(prefix),
            _ => Err(String::from("expected '+', ')' or EOF")),
        }
    }

    /* E
     * on number transition to number
     * on ( transition to ( S )
     * */
    fn parse_e(&mut self) -> Result<Ast, String> {
        println!("State: E \t\tLookahead: {:?}", self.toks.peek());
        match self.toks.peek() {
            Some(Token::Num(_)) => {
                Ok(Ast::Num(self.parse_num()?))
            }
            Some(Token::LParen) => {
                self.parse_tok(Token::LParen)?;
                let res = self.parse_s()?;
                self.parse_tok(Token::RParen)?;
                Ok(res)
            }
            _ => Err(String::from("expected '(' or number"))
        }
        // match self.toks.next() {
        //     Some(Token::Num(n)) => Ok(Ast::Num(*n)),
        //     Some(Token::LParen) => {
        //         let ans = self.parse_s()?;
        //         match self.toks.next() {
        //             Some(Token::RParen) => Ok(ans),
        //             _ => Err(String::from("expected ')'")),
        //         }
        //     }
        //     _ => Err(String::from("expected '(' or number")),
        // }
    }
}

fn parse<'t, T: Iterator<Item = &'t Token>>(toks: &mut T) -> Result<Ast, String> {
    let mut ps = ParserState {
        toks: toks.peekable(),
    };
    ps.parse_t()
}

fn main() {
    use Token::*;
    // (1 + 2 + (3 + 4)) + 5
    let test_input = vec![
        LParen,
        Num(1),
        Plus,
        Num(2),
        Plus,
        LParen,
        Num(3),
        Plus,
        Num(4),
        RParen,
        RParen,
        Plus,
        Num(5),
    ];
    println!("{:?}", test_input);
    println!(
        "Parsing (1 + 2 + (3 + 4)) + 5\n{:?}",
        parse(&mut test_input.iter())
    );
}
