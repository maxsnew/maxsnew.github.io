use std::env;
use std::fs;

fn main() {
    let args: Vec<String> = env::args().collect();
    let input = fs::read_to_string(&args[1]).unwrap();

    println!(
        "        section .text
        global start_here
start_here:
mov rax, {}
ret",
        input
    );
}
