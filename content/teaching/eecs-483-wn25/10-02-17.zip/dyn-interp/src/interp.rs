use crate::ast::*;

// Boa semantics: coercions
fn boolToInt(b: bool) -> i64 {
    if b {
        1
    } else {
        0
    }
}

fn intToBool(n: i64) -> bool {
    n != 0
}
pub fn interp_boa(e: &Expression) -> i64 {
    match e {
        Expression::Integer(n) => todo!(),
        Expression::Boolean(b) => todo!(),
        Expression::If(cond, thn, els) => todo!(),
        Expression::Prim1(Prim1::Not, e) => todo!(),
        Expression::Prim1(Prim1::IsInt, e) => todo!(),
        Expression::Prim1(Prim1::IsBool, e) => todo!(),
        Expression::Prim2(Prim2::Add, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Sub, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Mul, e1, e2) => todo!(),
        Expression::Prim2(Prim2::LEq, e1, e2) => todo!(),
        Expression::Prim2(Prim2::LT, e1, e2) => todo!(),
        Expression::Prim2(Prim2::GEq, e1, e2) => todo!(),
        Expression::Prim2(Prim2::GT, e1, e2) => todo!(),
        Expression::Prim2(Prim2::And, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Or, e1, e2) => todo!(),
    }
}

pub enum RuntimeError {
    ArithExpectedInt,
    CompareExpectedInt,
    LogExpectedBool,
    IfExpectedBool,
}

#[derive(Copy, Clone)]
pub enum SnakeVal {
    Integer(i64),
    Boolean(bool),
}

fn assert_int(v: SnakeVal) -> Option<i64> {
    match v {
        SnakeVal::Integer(n) => Some(n),
        SnakeVal::Boolean(_) => None,
    }
}

fn assert_bool(v: SnakeVal) -> Option<bool> {
    match v {
        SnakeVal::Boolean(b) => Some(b),
        SnakeVal::Integer(_) => None,
    }
}

pub fn interp_diamond(e: &Expression) -> Result<SnakeVal, RuntimeError> {
    match e {
        Expression::Integer(n) => todo!(),
        Expression::Boolean(b) => todo!(),
        Expression::If(cond, thn, els) => todo!(),
        Expression::Prim1(Prim1::Not, e) => todo!(),
        Expression::Prim1(Prim1::IsInt, e) => todo!(),
        Expression::Prim1(Prim1::IsBool, e) => todo!(),
        Expression::Prim2(Prim2::Add, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Sub, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Mul, e1, e2) => todo!(),
        Expression::Prim2(Prim2::LEq, e1, e2) => todo!(),
        Expression::Prim2(Prim2::LT, e1, e2) => todo!(),
        Expression::Prim2(Prim2::GEq, e1, e2) => todo!(),
        Expression::Prim2(Prim2::GT, e1, e2) => todo!(),
        Expression::Prim2(Prim2::And, e1, e2) => todo!(),
        Expression::Prim2(Prim2::Or, e1, e2) => todo!(),
    }
}
